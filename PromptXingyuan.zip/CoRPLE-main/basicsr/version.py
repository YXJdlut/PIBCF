# GENERATED VERSION FILE
# TIME: Fri Feb  2 21:06:53 2024
__version__ = '1.3.5'
__gitsha__ = '57637a3'
version_info = (1, 3, 5)
